import PageLayout from "@/src/components/PageLayout";
import { auth } from "@/src/services/auth";
import { Metadata } from "next";
import { headers } from "next/headers";
import { redirect } from "next/navigation";
import { columns, student } from "@/src/components/students/StudentColumns";
import { DataTable } from "./data-table";

export const metadata: Metadata = {
  title: "Students",
};

export default async function StudentsPage() {
  const session = await auth.api.getSession({ headers: await headers() });

  if (!session) {
    redirect("/login");
  }

  return (
    <PageLayout title="Students">
      <DataTable columns={columns} data={student} />
    </PageLayout>
  );
}
