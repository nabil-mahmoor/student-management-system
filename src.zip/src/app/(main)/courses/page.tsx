import PageLayout from "@/src/components/PageLayout";
import { auth } from "@/src/services/auth";
import { Metadata } from "next";
import { headers } from "next/headers";
import { redirect } from "next/navigation";
import { columns } from "@/src/components/courses/CourseColumns";
import courses from "./course-data.json";
import { DataTable } from "./data-table";

export const metadata: Metadata = {
  title: "Courses",
};

export default async function CoursesPage() {
  const session = await auth.api.getSession({ headers: await headers() });

  if (!session) {
    redirect("/login");
  }

  return (
    <PageLayout title="Courses">
      <DataTable data={courses} columns={columns} />
    </PageLayout>
  );
}
